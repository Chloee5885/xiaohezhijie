小河直街数字故事卡（静态网页复制版）

本版本以独立静态网页重制，封面使用用户指定的第一张照片 assets/cover.jpeg，未使用第二张照片。
包含：响应式首页、街区介绍、故事卡片弹窗、时光脉络、导航锚点。

本版本是根据可访问的公开入口和已提供素材制作的近似重制版；由于原站源代码和完整页面内容不可读取，无法保证像素级复刻。文案为概述性介绍，正式展示前建议核对史实与补充原站逐字内容。

部署到 GitHub Pages：
1. 在 GitHub 新建一个 Public repository。
2. 将本文件夹内 index.html、README.txt 和 assets 文件夹上传到仓库根目录。
3. 进入仓库 Settings -> Pages。
4. 在 Build and deployment 选择 Deploy from a branch；Branch 选 main，目录选 /(root)，保存。
5. 等待 GitHub Pages 发布，访问显示的 https://用户名.github.io/仓库名/ 网址。
6. 用该网址生成二维码即可。注意：二维码应指向部署后的公开网址，而不是本地文件。
